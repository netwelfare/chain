Example 1
=========
An example using the ChainProcessor servlet and showing examples of
using the PathInfoMapper, RequestParameterMapper and ServletPathMapper
Commands to map requests to Commands.

BUILDING
========
To build the example webapp you need Maven 2 installed:
   http://maven.apache.org/

Run the the following command to build the webapp war file:

   mvn package